import socket

def verificar_aprovacao(n1, n2, n3):
    media = (n1 + n2) / 2
    if media >= 7.0:
        return f"Aprovado com média {media:.2f}."
    elif media > 3.0:
        nova_media = (media + n3) / 2
        if nova_media >= 5.0:
            return f"Aprovado com média final {nova_media:.2f}."
        else:
            return f"Reprovado com média final {nova_media:.2f}."
    else:
        return f"Reprovado com média {media:.2f}."

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('localhost', 12345))
server_socket.listen(5)

print("Servidor aguardando conexões...")

while True:
    conn, addr = server_socket.accept()
    print(f"Conexão estabelecida com {addr}")
    
    data = conn.recv(1024).decode('utf-8')
    n1, n2, n3 = map(float, data.split(','))
    
    resultado = verificar_aprovacao(n1, n2, n3)
    
    conn.sendall(resultado.encode('utf-8'))
    conn.close()
