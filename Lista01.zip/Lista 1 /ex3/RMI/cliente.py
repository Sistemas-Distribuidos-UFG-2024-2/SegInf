import Pyro4

servidor = Pyro4.Proxy("PYRO:Aprovacao@localhost:1099")

n1 = float(input("Digite a nota N1: "))
n2 = float(input("Digite a nota N2: "))
n3 = float(input("Digite a nota N3 (caso necessário): "))

resultado = servidor.verificarAprovacao(n1, n2, n3)
print(resultado)
