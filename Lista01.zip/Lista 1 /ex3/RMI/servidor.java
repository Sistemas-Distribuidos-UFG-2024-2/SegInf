import java.rmi.*;
import java.rmi.server.*;

public class ServidorRMI extends UnicastRemoteObject implements Aprovacao {
    public ServidorRMI() throws RemoteException {}

    public String verificarAprovacao(float n1, float n2, float n3) throws RemoteException {
        float media = (n1 + n2) / 2;
        if (media >= 7.0) {
            return "Aprovado com média " + media;
        } else if (media > 3.0) {
            float nova_media = (media + n3) / 2;
            if (nova_media >= 5.0) {
                return "Aprovado com média final " + nova_media;
            } else {
                return "Reprovado com média final " + nova_media;
            }
        } else {
            return "Reprovado com média " + media;
        }
    }

    public static void main(String[] args) {
        try {
            Naming.rebind("rmi://localhost:1099/Aprovacao", new ServidorRMI());
            System.out.println("Servidor RMI pronto.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
