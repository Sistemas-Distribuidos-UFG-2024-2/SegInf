import java.rmi.*;

public interface Aprovacao extends Remote {
    String verificarAprovacao(float n1, float n2, float n3) throws RemoteException;
}
