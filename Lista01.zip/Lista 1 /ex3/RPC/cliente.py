import xmlrpc.client

proxy = xmlrpc.client.ServerProxy('http://localhost/aprovacao.php')

n1 = float(input("Digite a nota N1: "))
n2 = float(input("Digite a nota N2: "))
n3 = float(input("Digite a nota N3 (caso necessário): "))

resultado = proxy.verificarAprovacao(n1, n2, n3)
print(resultado)
