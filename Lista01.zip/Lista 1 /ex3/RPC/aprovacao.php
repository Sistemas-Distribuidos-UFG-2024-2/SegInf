<?php
require_once 'vendor/autoload.php';

use PhpXmlRpc\Server;
use PhpXmlRpc\Request;
use PhpXmlRpc\Response;
use PhpXmlRpc\Value;

function verificarAprovacao($params) {
    $n1 = $params[0]->scalarval();
    $n2 = $params[1]->scalarval();
    $n3 = $params[2]->scalarval();
    
    $media = ($n1 + $n2) / 2;
    
    if ($media >= 7.0) {
        $resultado = "Aprovado com média $media.";
    } elseif ($media > 3.0) {
        $nova_media = ($media + $n3) / 2;
        if ($nova_media >= 5.0) {
            $resultado = "Aprovado com média final $nova_media.";
        } else {
            $resultado = "Reprovado com média final $nova_media.";
        }
    } else {
        $resultado = "Reprovado com média $media.";
    }
    
    return new Response(new Value($resultado));
}

$server = new Server();
$server->addCallback('verificarAprovacao', 'verificarAprovacao');
$server->service();
?>
