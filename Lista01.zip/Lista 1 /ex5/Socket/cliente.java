import java.io.*;
import java.net.*;

public class ClienteSocket {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 12345);
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Digite a idade do nadador:");
            String idade = reader.readLine();

            out.println(idade);

            String resposta = in.readLine();
            System.out.println("Classificação: " + resposta);

            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
