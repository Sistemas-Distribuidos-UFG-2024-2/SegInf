import socket

def classificar_nadador(idade):
    if 5 <= idade <= 7:
        return "Infantil A"
    elif 8 <= idade <= 10:
        return "Infantil B"
    elif 11 <= idade <= 13:
        return "Juvenil A"
    elif 14 <= idade <= 17:
        return "Juvenil B"
    elif idade >= 18:
        return "Adulto"
    else:
        return "Fora da faixa etária para nadadores."

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('localhost', 12345))
server_socket.listen(5)

print("Servidor aguardando conexões...")

while True:
    conn, addr = server_socket.accept()
    print(f"Conexão estabelecida com {addr}")
    
    idade = int(conn.recv(1024).decode('utf-8'))
    
    categoria = classificar_nadador(idade)
    
    conn.sendall(categoria.encode('utf-8'))
    conn.close()
