import Pyro4

servidor = Pyro4.Proxy("PYRO:Classificacao@localhost:1099")

idade = int(input("Digite a idade do nadador: "))

categoria = servidor.classificarNadador(idade)
print(f"Classificação: {categoria}")
