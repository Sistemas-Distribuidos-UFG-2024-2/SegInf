import java.rmi.*;

public interface Classificacao extends Remote {
    String classificarNadador(int idade) throws RemoteException;
}
