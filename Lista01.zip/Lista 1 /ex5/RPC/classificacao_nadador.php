<?php
require_once 'vendor/autoload.php';

use PhpXmlRpc\Server;
use PhpXmlRpc\Request;
use PhpXmlRpc\Response;
use PhpXmlRpc\Value;

function classificarNadador($params) {
    $idade = $params[0]->scalarval();
    
    if ($idade >= 5 && $idade <= 7) {
        $categoria = "Infantil A";
    } elseif ($idade >= 8 && $idade <= 10) {
        $categoria = "Infantil B";
    } elseif ($idade >= 11 && $idade <= 13) {
        $categoria = "Juvenil A";
    } elseif ($idade >= 14 && $idade <= 17) {
        $categoria = "Juvenil B";
    } elseif ($idade >= 18) {
        $categoria = "Adulto";
    } else {
        $categoria = "Fora da faixa etária para nadadores.";
    }

    return new Response(new Value($categoria));
}

$server = new Server();
$server->addCallback('classificarNadador', 'classificarNadador');
$server->service();
?>
