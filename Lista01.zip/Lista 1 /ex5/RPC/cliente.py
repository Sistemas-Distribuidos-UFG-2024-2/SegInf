import xmlrpc.client

proxy = xmlrpc.client.ServerProxy('http://localhost/classificacao_nadador.php')

idade = int(input("Digite a idade do nadador: "))

categoria = proxy.classificarNadador(idade)
print(f"Classificação: {categoria}")
