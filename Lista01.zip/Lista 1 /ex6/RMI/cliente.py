import rpyc

class ClientService(rpyc.Service):
    def on_connect(self, conn):
        print("Conectado ao servidor.")

    def on_disconnect(self, conn):
        print("Desconectado do servidor.")

    def exposed_calcular_salario(self):
        nome = input("Digite o nome do funcionário: ")
        nivel = input("Digite o nível do funcionário (A, B, C, D): ")
        salario_bruto = float(input("Digite o salário bruto: "))
        dependentes = int(input("Digite o número de dependentes: "))
        return self.calcular_salario_liquido(nome, nivel, salario_bruto, dependentes)

    def calcular_salario_liquido(self, nome, nivel, salario_bruto, dependentes):
        if nivel == "A":
            desconto = 0.03 if dependentes == 0 else 0.08
        elif nivel == "B":
            desconto = 0.05 if dependentes == 0 else 0.10
        elif nivel == "C":
            desconto = 0.08 if dependentes == 0 else 0.15
        elif nivel == "D":
            desconto = 0.10 if dependentes == 0 else 0.17
        else:
            raise ValueError("Nível inválido.")
        
        salario_liquido = salario_bruto * (1 - desconto)
        return {"nome": nome, "nivel": nivel, "salario_liquido": salario_liquido}

if __name__ == "__main__":
    from rpyc import connect
    conn = connect('localhost', 18861)
    resultado = conn.root.calcular_salario()
    print(f"Nome: {resultado['nome']}, Nível: {resultado['nivel']}, Salário Líquido: {resultado['salario_liquido']:.2f}")
