import java.rmi.*;
import java.rmi.server.*;

public interface Funcionario extends Remote {
    double calcularSalarioLiquido(String nome, String nivel, double salarioBruto, int dependentes) throws RemoteException;
}

public class FuncionarioImpl extends UnicastRemoteObject implements Funcionario {
    public FuncionarioImpl() throws RemoteException {
        super();
    }

    public double calcularSalarioLiquido(String nome, String nivel, double salarioBruto, int dependentes) throws RemoteException {
        double desconto;
        switch (nivel) {
            case "A":
                desconto = (dependentes == 0) ? 0.03 : 0.08;
                break;
            case "B":
                desconto = (dependentes == 0) ? 0.05 : 0.10;
                break;
            case "C":
                desconto = (dependentes == 0) ? 0.08 : 0.15;
                break;
            case "D":
                desconto = (dependentes == 0) ? 0.10 : 0.17;
                break;
            default:
                throw new RemoteException("Nível inválido.");
        }
        return salarioBruto * (1 - desconto);
    }

    public static void main(String[] args) {
        try {
            FuncionarioImpl servidor = new FuncionarioImpl();
            Naming.rebind("FuncionarioService", servidor);
            System.out.println("Servidor pronto.");
        } catch (Exception e) {
            System.out.println("Erro: " + e);
        }
    }
}
