import xmlrpc.client

def main():
    server = xmlrpc.client.ServerProxy("http://localhost:8000/")
    
    nome = input("Digite o nome do funcionário: ")
    nivel = input("Digite o nível do funcionário (A, B, C, D): ")
    salario_bruto = float(input("Digite o salário bruto: "))
    dependentes = int(input("Digite o número de dependentes: "))

    salario_liquido = server.calcular_salario_liquido(nome, nivel, salario_bruto, dependentes)
    print(f"Nome: {nome}, Nível: {nivel}, Salário Líquido: {salario_liquido:.2f}")

if __name__ == "__main__":
    main()
