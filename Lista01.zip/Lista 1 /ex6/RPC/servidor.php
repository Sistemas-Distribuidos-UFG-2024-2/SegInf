<?php
function calcular_salario_liquido($nome, $nivel, $salario_bruto, $dependentes) {
    switch ($nivel) {
        case 'A':
            $desconto = ($dependentes == 0) ? 0.03 : 0.08;
            break;
        case 'B':
            $desconto = ($dependentes == 0) ? 0.05 : 0.10;
            break;
        case 'C':
            $desconto = ($dependentes == 0) ? 0.08 : 0.15;
            break;
        case 'D':
            $desconto = ($dependentes == 0) ? 0.10 : 0.17;
            break;
        default:
            return "Nível inválido.";
    }
    $salario_liquido = $salario_bruto * (1 - $desconto);
    return $salario_liquido;
}

require('xmlrpc.inc');
$server = new xmlrpc_server();
$server->add_function('calcular_salario_liquido');
$server->serve();
?>
