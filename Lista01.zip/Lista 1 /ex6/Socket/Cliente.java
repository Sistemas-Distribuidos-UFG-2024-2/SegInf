import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 12345);
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            DataInputStream in = new DataInputStream(socket.getInputStream());

            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Digite o nome do funcionário: ");
            String nome = reader.readLine();
            System.out.print("Digite o nível do funcionário (A, B, C, D): ");
            String nivel = reader.readLine();
            System.out.print("Digite o salário bruto: ");
            double salario_bruto = Double.parseDouble(reader.readLine());
            System.out.print("Digite o número de dependentes: ");
            int dependentes = Integer.parseInt(reader.readLine());

            out.writeUTF(nome);
            out.writeUTF(nivel);
            out.writeDouble(salario_bruto);
            out.writeInt(dependentes);
            out.flush();

            double salario_liquido = in.readDouble();
            System.out.println("Salário Líquido: " + salario_liquido);

            socket.close();
        } catch (IOException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}
