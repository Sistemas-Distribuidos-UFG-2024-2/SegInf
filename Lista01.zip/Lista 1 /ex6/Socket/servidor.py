import socket

def calcular_salario_liquido(nome, nivel, salario_bruto, dependentes):
    if nivel == "A":
        desconto = 0.03 if dependentes == 0 else 0.08
    elif nivel == "B":
        desconto = 0.05 if dependentes == 0 else 0.10
    elif nivel == "C":
        desconto = 0.08 if dependentes == 0 else 0.15
    elif nivel == "D":
        desconto = 0.10 if dependentes == 0 else 0.17
    else:
        return None

    return salario_bruto * (1 - desconto)

def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("localhost", 12345))
    server_socket.listen(5)
    print("Servidor pronto e aguardando conexões...")

    while True:
        client_socket, addr = server_socket.accept()
        print(f"Conexão recebida de {addr}")

        nome = client_socket.recv(1024).decode('utf-8')
        nivel = client_socket.recv(1024).decode('utf-8')
        salario_bruto = float(client_socket.recv(1024).decode('utf-8'))
        dependentes = int(client_socket.recv(1024).decode('utf-8'))

        salario_liquido = calcular_salario_liquido(nome, nivel, salario_bruto, dependentes)
        client_socket.sendall(str(salario_liquido).encode('utf-8'))

        client_socket.close()

if __name__ == "__main__":
    main()
