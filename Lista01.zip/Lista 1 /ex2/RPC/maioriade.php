<?php
require_once 'vendor/autoload.php';

use PhpXmlRpc\Server;
use PhpXmlRpc\Request;
use PhpXmlRpc\Response;
use PhpXmlRpc\Value;

function verificarMaioridade($params) {
    $nome = $params[0]->scalarval();
    $sexo = $params[1]->scalarval();
    $idade = $params[2]->scalarval();
    
    if ($sexo == 'masculino' && $idade >= 18) {
        $resultado = "$nome já atingiu a maioridade.";
    } elseif ($sexo == 'feminino' && $idade >= 21) {
        $resultado = "$nome já atingiu a maioridade.";
    } else {
        $resultado = "$nome ainda não atingiu a maioridade.";
    }
    
    return new Response(new Value($resultado));
}

$server = new Server();
$server->addCallback('verificarMaioridade', 'verificarMaioridade');
$server->service();
?>
