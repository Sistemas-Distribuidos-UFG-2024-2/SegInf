import xmlrpc.client

proxy = xmlrpc.client.ServerProxy('http://localhost/maioridade.php')

nome = input("Digite o nome da pessoa: ")
sexo = input("Digite o sexo da pessoa (masculino/feminino): ").lower()
idade = int(input("Digite a idade da pessoa: "))

resultado = proxy.verificarMaioridade(nome, sexo, idade)
print(resultado)
