import java.rmi.*;
import java.rmi.server.*;

public class ServidorRMI extends UnicastRemoteObject implements Maioridade {
    public ServidorRMI() throws RemoteException {}

    public String verificarMaioridade(String nome, String sexo, int idade) throws RemoteException {
        if (sexo.equals("masculino") && idade >= 18) {
            return nome + " já atingiu a maioridade.";
        } else if (sexo.equals("feminino") && idade >= 21) {
            return nome + " já atingiu a maioridade.";
        } else {
            return nome + " ainda não atingiu a maioridade.";
        }
    }

    public static void main(String[] args) {
        try {
            Naming.rebind("rmi://localhost:1099/Maioridade", new ServidorRMI());
            System.out.println("Servidor RMI pronto.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
