import Pyro4

servidor = Pyro4.Proxy("PYRO:Maioridade@localhost:1099")

nome = input("Digite o nome da pessoa: ")
sexo = input("Digite o sexo da pessoa (masculino/feminino): ").lower()
idade = int(input("Digite a idade da pessoa: "))

resultado = servidor.verificarMaioridade(nome, sexo, idade)
print(resultado)
