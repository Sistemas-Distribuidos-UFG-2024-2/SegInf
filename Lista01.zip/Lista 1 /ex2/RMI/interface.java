import java.rmi.*;

public interface Maioridade extends Remote {
    String verificarMaioridade(String nome, String sexo, int idade) throws RemoteException;
}
