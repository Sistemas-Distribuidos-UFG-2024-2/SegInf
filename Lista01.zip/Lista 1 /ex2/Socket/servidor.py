import socket

def verificar_maioridade(sexo, idade):
    if sexo == 'masculino' and idade >= 18:
        return "Já atingiu a maioridade."
    elif sexo == 'feminino' and idade >= 21:
        return "Já atingiu a maioridade."
    return "Ainda não atingiu a maioridade."

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('localhost', 12345))
server_socket.listen(5)

print("Servidor aguardando conexões...")

while True:
    conn, addr = server_socket.accept()
    print(f"Conexão estabelecida com {addr}")
    
    data = conn.recv(1024).decode('utf-8')
    nome, sexo, idade = data.split(',')
    idade = int(idade)
    
    resultado = verificar_maioridade(sexo, idade)
    
    resposta = f"Nome: {nome}, {resultado}"
    conn.sendall(resposta.encode('utf-8'))
    conn.close()
