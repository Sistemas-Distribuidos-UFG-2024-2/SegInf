import xmlrpc.client

def main():
    server = xmlrpc.client.ServerProxy("http://localhost:8000/")
    
    valor = int(input("Digite o valor da carta (1 a 13): "))
    naipe = int(input("Digite o naipe da carta (1: ouros, 2: paus, 3: copas, 4: espadas): "))

    nome_carta = server.imprimir_nome(valor, naipe)
    print(f"Carta: {nome_carta}")

if __name__ == "__main__":
    main()
