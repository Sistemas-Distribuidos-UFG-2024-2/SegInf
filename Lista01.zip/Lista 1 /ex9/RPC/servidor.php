<?php
function imprimir_nome($valor, $naipe) {
    $valores = ["Ás", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Valete", "Dama", "Rei"];
    $naipes = ["Ouros", "Paus", "Copas", "Espadas"];

    return "{$valores[$valor - 1]} de {$naipes[$naipe - 1]}";
}

require('xmlrpc.inc');
$server = new xmlrpc_server();
$server->add_function('imprimir_nome');
$server->serve();
?>
