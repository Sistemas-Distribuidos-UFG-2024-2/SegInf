import java.rmi.*;
import java.rmi.server.*;

public interface CartaInterface extends Remote {
    String imprimirNome() throws RemoteException;
}

public class Carta extends UnicastRemoteObject implements CartaInterface {
    private int valor; // 1 a 13
    private int naipe; // 1: ouros, 2: paus, 3: copas, 4: espadas

    public Carta(int valor, int naipe) throws RemoteException {
        super();
        this.valor = valor;
        this.naipe = naipe;
    }

    public String imprimirNome() throws RemoteException {
        String[] valores = {"Ás", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Valete", "Dama", "Rei"};
        String[] naipes = {"Ouros", "Paus", "Copas", "Espadas"};

        return String.format("%s de %s", valores[valor - 1], naipes[naipe - 1]);
    }

    public static void main(String[] args) {
        try {
            Carta carta = new Carta(1, 1); // Exemplo de instância
            Naming.rebind("CartaService", carta);
            System.out.println("Servidor de cartas pronto.");
        } catch (Exception e) {
            System.out.println("Erro: " + e);
        }
    }
}
