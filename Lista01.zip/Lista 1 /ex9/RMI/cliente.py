import rpyc

class ClientService(rpyc.Service):
    def on_connect(self, conn):
        print("Conectado ao servidor.")

    def on_disconnect(self, conn):
        print("Desconectado do servidor.")

    def exposed_obter_carta(self):
        valor = int(input("Digite o valor da carta (1 a 13): "))
        naipe = int(input("Digite o naipe da carta (1: ouros, 2: paus, 3: copas, 4: espadas): "))
        carta = self.criar_carta(valor, naipe)
        return carta.imprimir_nome()

    def criar_carta(self, valor, naipe):
        from carta import Carta  # Importa a classe Carta
        return Carta(valor, naipe)

if __name__ == "__main__":
    from rpyc import connect
    conn = connect('localhost', 18861)
    resultado = conn.root.obter_carta()
    print(resultado)
