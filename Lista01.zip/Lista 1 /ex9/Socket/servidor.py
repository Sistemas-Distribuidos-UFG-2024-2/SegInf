import socket

def imprimir_nome(valor, naipe):
    valores = ["Ás", "2", "3", "4", "5", "6", "7", "8", "9", "10", "Valete", "Dama", "Rei"]
    naipes = ["Ouros", "Paus", "Copas", "Espadas"]

    return f"{valores[valor - 1]} de {naipes[naipe - 1]}"

def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("localhost", 12345))
    server_socket.listen(5)
    print("Servidor de cartas pronto e aguardando conexões...")

    while True:
        client_socket, addr = server_socket.accept()
        print(f"Conexão recebida de {addr}")

        valor = client_socket.recv(1024)
        naipe = client_socket.recv(1024)

        valor = int.from_bytes(valor, byteorder='big')
        naipe = int.from_bytes(naipe, byteorder='big')

        nome_carta = imprimir_nome(valor, naipe)
        client_socket.sendall(nome_carta.encode('utf-8'))

        client_socket.close()

if __name__ == "__main__":
    main()
