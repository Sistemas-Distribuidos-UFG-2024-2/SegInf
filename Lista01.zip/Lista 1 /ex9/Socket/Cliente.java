import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 12345);
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            DataInputStream in = new DataInputStream(socket.getInputStream());

            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Digite o valor da carta (1 a 13): ");
            int valor = Integer.parseInt(reader.readLine());
            System.out.print("Digite o naipe da carta (1: ouros, 2: paus, 3: copas, 4: espadas): ");
            int naipe = Integer.parseInt(reader.readLine());

            out.writeInt(valor);
            out.writeInt(naipe);
            out.flush();

            String nome_carta = in.readUTF();
            System.out.println("Carta: " + nome_carta);

            socket.close();
        } catch (IOException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}
