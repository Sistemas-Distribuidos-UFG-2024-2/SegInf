<?php
function calcular_credito($saldo_medio) {
    if ($saldo_medio <= 200) {
        return 0.0;
    } elseif ($saldo_medio <= 400) {
        return $saldo_medio * 0.20;
    } elseif ($saldo_medio <= 600) {
        return $saldo_medio * 0.30;
    } else {
        return $saldo_medio * 0.40;
    }
}

require('xmlrpc.inc');
$server = new xmlrpc_server();
$server->add_function('calcular_credito');
$server->serve();
?>
