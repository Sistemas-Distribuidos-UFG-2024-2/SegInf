import rpyc

class ClientService(rpyc.Service):
    def on_connect(self, conn):
        print("Conectado ao servidor.")

    def on_disconnect(self, conn):
        print("Desconectado do servidor.")

    def exposed_calcular_credito(self):
        saldo_medio = float(input("Digite o saldo médio do cliente: "))
        return self.calcular_credito(saldo_medio)

    def calcular_credito(self, saldo_medio):
        if saldo_medio <= 200:
            credito = 0.0
        elif 201 <= saldo_medio <= 400:
            credito = saldo_medio * 0.20
        elif 401 <= saldo_medio <= 600:
            credito = saldo_medio * 0.30
        else:
            credito = saldo_medio * 0.40
        
        return {"saldo_medio": saldo_medio, "credito": credito}

if __name__ == "__main__":
    from rpyc import connect
    conn = connect('localhost', 18861)
    resultado = conn.root.calcular_credito()
    print(f"Saldo Médio: {resultado['saldo_medio']:.2f}, Crédito: {resultado['credito']:.2f}")
