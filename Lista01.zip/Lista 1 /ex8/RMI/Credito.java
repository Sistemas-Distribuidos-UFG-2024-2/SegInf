import java.rmi.*;
import java.rmi.server.*;

public interface Credito extends Remote {
    double calcularCredito(double saldoMedio) throws RemoteException;
}

public class CreditoImpl extends UnicastRemoteObject implements Credito {
    public CreditoImpl() throws RemoteException {
        super();
    }

    public double calcularCredito(double saldoMedio) throws RemoteException {
        double credito;
        if (saldoMedio <= 200) {
            credito = 0.0;
        } else if (saldoMedio <= 400) {
            credito = saldoMedio * 0.20;
        } else if (saldoMedio <= 600) {
            credito = saldoMedio * 0.30;
        } else {
            credito = saldoMedio * 0.40;
        }
        return credito;
    }

    public static void main(String[] args) {
        try {
            CreditoImpl servidor = new CreditoImpl();
            Naming.rebind("CreditoService", servidor);
            System.out.println("Servidor pronto.");
        } catch (Exception e) {
            System.out.println("Erro: " + e);
        }
    }
}
