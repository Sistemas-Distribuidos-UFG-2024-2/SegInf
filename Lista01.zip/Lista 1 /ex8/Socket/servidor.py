import socket

def calcular_credito(saldo_medio):
    if saldo_medio <= 200:
        return 0.0
    elif saldo_medio <= 400:
        return saldo_medio * 0.20
    elif saldo_medio <= 600:
        return saldo_medio * 0.30
    else:
        return saldo_medio * 0.40

def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("localhost", 12345))
    server_socket.listen(5)
    print("Servidor pronto e aguardando conexões...")

    while True:
        client_socket, addr = server_socket.accept()
        print(f"Conexão recebida de {addr}")

        saldo_medio = client_socket.recv(1024)
        saldo_medio = float.from_bytes(saldo_medio, byteorder='big')

        credito = calcular_credito(saldo_medio)
        client_socket.sendall(credit.to_bytes(8, byteorder='big'))

        client_socket.close()

if __name__ == "__main__":
    main()
