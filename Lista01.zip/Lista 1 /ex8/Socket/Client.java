import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 12345);
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            DataInputStream in = new DataInputStream(socket.getInputStream());

            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Digite o saldo médio do cliente: ");
            double saldoMedio = Double.parseDouble(reader.readLine());

            out.writeDouble(saldoMedio);
            out.flush();

            double credito = in.readDouble();
            System.out.println(String.format("Saldo Médio: %.2f, Crédito: %.2f", saldoMedio, credito));

            socket.close();
        } catch (IOException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}
