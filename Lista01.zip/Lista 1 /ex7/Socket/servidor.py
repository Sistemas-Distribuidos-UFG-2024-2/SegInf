import socket

def pode_aposentar(idade, tempo_servico):
    return (idade >= 65 and tempo_servico >= 30) or (idade >= 60 and tempo_servico >= 25)

def main():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind(("localhost", 12345))
    server_socket.listen(5)
    print("Servidor pronto e aguardando conexões...")

    while True:
        client_socket, addr = server_socket.accept()
        print(f"Conexão recebida de {addr}")

        idade = client_socket.recv(1024)
        tempo_servico = client_socket.recv(1024)
        
        idade = int.from_bytes(idade, byteorder='big')
        tempo_servico = int.from_bytes(tempo_servico, byteorder='big')

        pode_aposentar_resultado = pode_aposentar(idade, tempo_servico)
        client_socket.sendall(bytes([1 if pode_aposentar_resultado else 0]))

        client_socket.close()

if __name__ == "__main__":
    main()
