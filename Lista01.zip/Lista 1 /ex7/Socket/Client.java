import java.io.*;
import java.net.*;

public class Client {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 12345);
            DataOutputStream out = new DataOutputStream(socket.getOutputStream());
            DataInputStream in = new DataInputStream(socket.getInputStream());

            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.print("Digite a idade do funcionário: ");
            int idade = Integer.parseInt(reader.readLine());
            System.out.print("Digite o tempo de serviço em anos: ");
            int tempoServico = Integer.parseInt(reader.readLine());

            out.writeInt(idade);
            out.writeInt(tempoServico);
            out.flush();

            boolean podeAposentar = in.readBoolean();
            if (podeAposentar) {
                System.out.println("O funcionário pode se aposentar.");
            } else {
                System.out.println("O funcionário não pode se aposentar.");
            }

            socket.close();
        } catch (IOException e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
}
