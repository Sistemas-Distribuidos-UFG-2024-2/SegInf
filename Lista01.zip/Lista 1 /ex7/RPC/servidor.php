<?php
function pode_aposentar($idade, $tempoServico) {
    return ($idade >= 65 && $tempoServico >= 30) || ($idade >= 60 && $tempoServico >= 25);
}

require('xmlrpc.inc');
$server = new xmlrpc_server();
$server->add_function('pode_aposentar');
$server->serve();
?>
