import xmlrpc.client

def main():
    server = xmlrpc.client.ServerProxy("http://localhost:8000/")
    
    idade = int(input("Digite a idade do funcionário: "))
    tempo_servico = int(input("Digite o tempo de serviço em anos: "))

    pode_aposentar = server.pode_aposentar(idade, tempo_servico)
    if pode_aposentar:
        print("O funcionário pode se aposentar.")
    else:
        print("O funcionário não pode se aposentar.")

if __name__ == "__main__":
    main()
