import java.rmi.*;
import java.rmi.server.*;

public interface Aposentadoria extends Remote {
    boolean podeAposentar(int idade, int tempoServico) throws RemoteException;
}

public class AposentadoriaImpl extends UnicastRemoteObject implements Aposentadoria {
    public AposentadoriaImpl() throws RemoteException {
        super();
    }

    public boolean podeAposentar(int idade, int tempoServico) throws RemoteException {
        return (idade >= 65 && tempoServico >= 30) || (idade >= 60 && tempoServico >= 25);
    }

    public static void main(String[] args) {
        try {
            AposentadoriaImpl servidor = new AposentadoriaImpl();
            Naming.rebind("AposentadoriaService", servidor);
            System.out.println("Servidor pronto.");
        } catch (Exception e) {
            System.out.println("Erro: " + e);
        }
    }
}
