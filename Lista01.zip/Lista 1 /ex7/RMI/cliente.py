import rpyc

class ClientService(rpyc.Service):
    def on_connect(self, conn):
        print("Conectado ao servidor.")

    def on_disconnect(self, conn):
        print("Desconectado do servidor.")

    def exposed_verificar_aposentadoria(self):
        idade = int(input("Digite a idade do funcionário: "))
        tempo_servico = int(input("Digite o tempo de serviço em anos: "))
        return self.pode_aposentar(idade, tempo_servico)

    def pode_aposentar(self, idade, tempo_servico):
        if idade >= 65 and tempo_servico >= 30:
            return True
        elif idade >= 60 and tempo_servico >= 25:
            return True
        return False

if __name__ == "__main__":
    from rpyc import connect
    conn = connect('localhost', 18861)
    resultado = conn.root.verificar_aposentadoria()
    if resultado:
        print("O funcionário pode se aposentar.")
    else:
        print("O funcionário não pode se aposentar.")
