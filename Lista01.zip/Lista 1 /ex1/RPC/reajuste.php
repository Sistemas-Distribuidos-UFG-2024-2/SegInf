<?php
require_once 'vendor/autoload.php';

use PhpXmlRpc\Server;
use PhpXmlRpc\Request;
use PhpXmlRpc\Response;
use PhpXmlRpc\Value;

function calcularReajuste($params) {
    $nome = $params[0]->scalarval();
    $cargo = $params[1]->scalarval();
    $salario = $params[2]->scalarval();
    
    if ($cargo == 'operador') {
        $salario_reajustado = $salario * 1.20;
    } elseif ($cargo == 'programador') {
        $salario_reajustado = $salario * 1.18;
    } else {
        $salario_reajustado = $salario;
    }
    
    return new Response(new Value("Nome: $nome, Salário reajustado: " . number_format($salario_reajustado, 2)));
}

$server = new Server();
$server->addCallback('calcularReajuste', 'calcularReajuste');
$server->service();
?>
