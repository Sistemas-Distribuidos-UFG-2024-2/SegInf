import xmlrpc.client

proxy = xmlrpc.client.ServerProxy('http://localhost/reajuste.php')

nome = input("Digite o nome do funcionário: ")
cargo = input("Digite o cargo do funcionário (operador/programador): ").lower()
salario = float(input("Digite o salário do funcionário: "))

result = proxy.calcularReajuste(nome, cargo, salario)
print(result)
