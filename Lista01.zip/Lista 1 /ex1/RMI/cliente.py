import Pyro4

servidor = Pyro4.Proxy("PYRO:Reajuste@localhost:1099")

nome = input("Digite o nome do funcionário: ")
cargo = input("Digite o cargo do funcionário (operador/programador): ").lower()
salario = float(input("Digite o salário do funcionário: "))

resultado = servidor.calcularReajuste(nome, cargo, salario)
print(resultado)
