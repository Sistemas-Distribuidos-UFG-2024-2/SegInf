import java.rmi.*;
import java.rmi.server.*;

public class ServidorRMI extends UnicastRemoteObject implements Reajuste {
    public ServidorRMI() throws RemoteException {}

    public String calcularReajuste(String nome, String cargo, double salario) throws RemoteException {
        double salarioReajustado;
        if (cargo.equals("operador")) {
            salarioReajustado = salario * 1.20;
        } else if (cargo.equals("programador")) {
            salarioReajustado = salario * 1.18;
        } else {
            salarioReajustado = salario;
        }
        return "Nome: " + nome + ", Salário Reajustado: " + String.format("%.2f", salarioReajustado);
    }

    public static void main(String[] args) {
        try {
            Naming.rebind("rmi://localhost:1099/Reajuste", new ServidorRMI());
            System.out.println("Servidor RMI pronto.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
