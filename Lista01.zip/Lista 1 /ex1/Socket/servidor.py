import socket

def calcular_reajuste(cargo, salario):
    if cargo == 'operador':
        return salario * 1.20
    elif cargo == 'programador':
        return salario * 1.18
    return salario

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('localhost', 12345))
server_socket.listen(5)

print("Servidor aguardando conexões...")

while True:
    conn, addr = server_socket.accept()
    print(f"Conexão estabelecida com {addr}")
    
    data = conn.recv(1024).decode('utf-8')
    nome, cargo, salario = data.split(',')
    salario = float(salario)
    
    salario_reajustado = calcular_reajuste(cargo, salario)
    
    resposta = f"Nome: {nome}, Salário Reajustado: {salario_reajustado:.2f}"
    conn.sendall(resposta.encode('utf-8'))
    conn.close()
