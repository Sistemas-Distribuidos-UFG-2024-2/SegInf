import java.rmi.*;

public interface PesoIdeal extends Remote {
    String calcularPesoIdeal(float altura, String sexo) throws RemoteException;
}
