import Pyro4

servidor = Pyro4.Proxy("PYRO:PesoIdeal@localhost:1099")

altura = float(input("Digite sua altura (em metros): "))
sexo = input("Digite seu sexo (M para masculino, F para feminino): ").upper()

resultado = servidor.calcularPesoIdeal(altura, sexo)
print(resultado)
