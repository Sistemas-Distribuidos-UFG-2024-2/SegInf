import java.rmi.*;
import java.rmi.server.*;

public class ServidorRMI extends UnicastRemoteObject implements PesoIdeal {
    public ServidorRMI() throws RemoteException {}

    public String calcularPesoIdeal(float altura, String sexo) throws RemoteException {
        float pesoIdeal;
        if (sexo.equals("M")) {
            pesoIdeal = (72.7f * altura) - 58;
        } else if (sexo.equals("F")) {
            pesoIdeal = (62.1f * altura) - 44.7f;
        } else {
            return "Sexo inválido";
        }
        return "O peso ideal é " + pesoIdeal + " kg.";
    }

    public static void main(String[] args) {
        try {
            Naming.rebind("rmi://localhost:1099/PesoIdeal", new ServidorRMI());
            System.out.println("Servidor RMI pronto.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
