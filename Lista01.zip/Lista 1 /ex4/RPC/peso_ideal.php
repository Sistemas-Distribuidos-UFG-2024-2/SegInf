<?php
require_once 'vendor/autoload.php';

use PhpXmlRpc\Server;
use PhpXmlRpc\Request;
use PhpXmlRpc\Response;
use PhpXmlRpc\Value;

function calcularPesoIdeal($params) {
    $altura = $params[0]->scalarval();
    $sexo = $params[1]->scalarval();
    
    if ($sexo == "M") {
        $peso_ideal = (72.7 * $altura) - 58;
    } else if ($sexo == "F") {
        $peso_ideal = (62.1 * $altura) - 44.7;
    } else {
        return new Response(new Value("Sexo inválido"));
    }
    
    return new Response(new Value("O peso ideal é $peso_ideal kg."));
}

$server = new Server();
$server->addCallback('calcularPesoIdeal', 'calcularPesoIdeal');
$server->service();
?>
