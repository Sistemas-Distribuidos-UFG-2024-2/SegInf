import xmlrpc.client

proxy = xmlrpc.client.ServerProxy('http://localhost/peso_ideal.php')

altura = float(input("Digite sua altura (em metros): "))
sexo = input("Digite seu sexo (M para masculino, F para feminino): ").upper()

resultado = proxy.calcularPesoIdeal(altura, sexo)
print(resultado)
