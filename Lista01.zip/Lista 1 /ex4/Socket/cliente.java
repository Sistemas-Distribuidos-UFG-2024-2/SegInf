import java.io.*;
import java.net.*;

public class ClienteSocket {
    public static void main(String[] args) {
        try {
            Socket socket = new Socket("localhost", 12345);
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
            BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

            BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));
            System.out.println("Digite sua altura (em metros):");
            String altura = reader.readLine();
            System.out.println("Digite seu sexo (M para masculino, F para feminino):");
            String sexo = reader.readLine();

            out.println(altura + "," + sexo);

            String resposta = in.readLine();
            System.out.println("Resposta do servidor: " + resposta);

            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
