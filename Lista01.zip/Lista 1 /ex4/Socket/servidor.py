import socket

def calcular_peso_ideal(altura, sexo):
    if sexo == 'M':
        return (72.7 * altura) - 58
    elif sexo == 'F':
        return (62.1 * altura) - 44.7
    else:
        return "Sexo inválido"

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind(('localhost', 12345))
server_socket.listen(5)

print("Servidor aguardando conexões...")

while True:
    conn, addr = server_socket.accept()
    print(f"Conexão estabelecida com {addr}")
    
    data = conn.recv(1024).decode('utf-8')
    altura, sexo = data.split(',')
    altura = float(altura)
    
    peso_ideal = calcular_peso_ideal(altura, sexo)
    
    conn.sendall(str(peso_ideal).encode('utf-8'))
    conn.close()
